﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Masina
    {
        public string marca { set; get; }
        public string model { set; get; }
        public string tipul { set; get; }
        public string dotari { set; get; }
        public double pret { set; get; }
        public int an { set; get; }
        public dotari dot { set; get; }
        public culoare color { set; get; }

        public DateTime dataInchieri = new DateTime();

        public Masina()
        {
            marca = model = tipul= null;
            pret = 0;
            an = 0;
        }
        public Masina(string n, string d,string tip, string dota, double p, int a, string c)
        {
            marca = n;
            model = d;
            tipul = tip;
            dot = (dotari)Enum.Parse(typeof(dotari),dota);
            pret = p;
            an = a;
            color = (culoare)Enum.Parse(typeof(culoare), c);
        }
        public string afisare()
        {
            return string.Format("{0,-5}{1,-10}{2,-15}{3,-10}{4,-10}{5,-10}{6,-15}",marca,model, tipul, dot,pret,an,color);
        }
    }
}
