﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public enum dotari
    {
        clima=1,
        head_up=2,
        inexistent=0,
    };
    public enum culoare
    {
        black=1,
        red=2,
        white=3,
        inexistent=0,
    };
}
