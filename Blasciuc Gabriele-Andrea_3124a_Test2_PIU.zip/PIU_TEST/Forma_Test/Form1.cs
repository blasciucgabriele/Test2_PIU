﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Test;
namespace Forma_Test
{
    public partial class Form1 : Form
    {
        List<Masina> masine = new List<Masina>();
        public Form1()
        {
            InitializeComponent();
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (textBox1.Text == "")
            {
                MessageBox.Show("Introduceti marca!");
                textBox1.BackColor = Color.Red;

            }
            else textBox1.BackColor = Color.GhostWhite;
            if (comboBox1.SelectedItem == null)
            {
                MessageBox.Show("Introduceti tipul!");
                comboBox1.BackColor = Color.Red;

            }
            else comboBox1.BackColor = Color.GhostWhite;
            if (radioButton2.Checked == false && radioButton3.Checked == false && radioButton4.Checked == false)
            {
                MessageBox.Show("Introduceti culoarea!");
            }
            int an;
            double pret;
            if (textBox2.Text == "")
            {
                MessageBox.Show("Introduceti modelul");
                textBox2.BackColor = Color.Red;

            }
            else textBox2.BackColor = Color.GhostWhite;
            if (textBox4.Text == "" || double.TryParse(textBox4.Text, out pret) != true)
            {
                MessageBox.Show("Introduceti Pretul/Format incorect!");
                textBox4.BackColor = Color.Red;

            }
            else textBox4.BackColor = Color.GhostWhite;
            if (textBox3.Text == "" || int.TryParse(textBox3.Text, out an) != true)
            {
                MessageBox.Show("Introduceti Stocul/Format incorect!");
                textBox3.BackColor = Color.Red;

            }
            else textBox3.BackColor = Color.GhostWhite;
            if ((checkBox1.Checked == false && checkBox2.Checked == false) || (checkBox1.Checked == true && checkBox2.Checked == true))
            {
                MessageBox.Show("Bifati doar o singura optiune(Mod Eliberare)!");
            }

            double pretul = 0;
            int anul = 0;
            if (int.TryParse(textBox3.Text, out anul) == true && double.TryParse(textBox4.Text, out pretul) == true && textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && (radioButton2.Checked == true || radioButton3.Checked == true || radioButton4.Checked == true) && comboBox1.SelectedItem != null && (checkBox1.Checked == true && checkBox2.Checked == false) || (checkBox1.Checked == false && checkBox2.Checked == true))
            {

                Masina m = new Masina(textBox1.Text, textBox2.Text, comboBox1.SelectedItem.ToString(), Convert.ToString(GetDotari()), pretul, anul, Convert.ToString(GetCuloare()));
                masine.Add(m);
                m.dataInchieri = DateTime.Now;
                MessageBox.Show("Masina adaugata!");


                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                checkBox1.Checked = false;
                checkBox2.Checked = false;
                checkBox3.Checked = false;
                textBox1.Text = textBox2.Text = textBox3.Text = textBox4.Text = "";
            
                comboBox1.SelectedIndex = -1;

            }
        }

        private culoare GetCuloare()
        {
            if (radioButton2.Checked)
                return culoare.black;
            if (radioButton3.Checked)
                return culoare.red;
            if (radioButton4.Checked)
                return culoare.white;
            return culoare.inexistent;
        }
        private dotari GetDotari()
        {
            if (checkBox1.Checked == true && checkBox2.Checked == false)
                return dotari.clima;
            if (checkBox2.Checked == true && checkBox1.Checked == false)
                return dotari.head_up;
            return dotari.inexistent;
        }
        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            var j = String.Format("{0,-5}{1,-15}{2,-20}{3,-15}{4,-12}{5,-10}{6,-10}{7,-20}\n", "Id", "Marca", "Model", "Tip", "Pret", "An", "Culoare", "Dotari");
            listBox1.Items.Add(j);
            if (masine.Count() == 0) MessageBox.Show("Nu exista produse!");
            else
            {
                int c = 1;
                foreach (Masina m in masine)
                {
                    var k = String.Format("{0,-5}{1,-15}{2,-20}{3,-15}{4,-12}{5,-10}{6,-10}{7,-20}\n", c, m.marca, m.model, Convert.ToString(m.tipul), m.pret, m.an, m.color.ToString(),m.dot.ToString());
                    listBox1.Items.Add(k);
                    c = c + 1;
                }
            }

        }
        private bool validare_nume(string nume)
        {
            foreach (Masina m in masine)
            {
                if (m.marca.Equals(nume))
                {
                    return true;
                }
            }
            return false;
        }
        private int get_index(string nume)
        {
            for (int i = 0; i < masine.Count(); i++)
            {
                if (nume == masine[i].marca)
                {
                    return i;
                }
            }
            return -1;
        }
        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked) MessageBox.Show("Blasciuc Gabriele-Andrea,3124a,FIESC C2");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "" || validare_nume(textBox1.Text)!=true)
            {
                MessageBox.Show("Introduceti marca/marca neexistent!");
                textBox1.BackColor = Color.Red;

            }
            else
            {

                int k = get_index(textBox1.Text);
                if (comboBox1.SelectedItem == null)
                {
                    MessageBox.Show("Introduceti tipul!");
                    comboBox1.BackColor = Color.Red;

                }
                else comboBox1.BackColor = Color.GhostWhite;
                if (radioButton2.Checked == false && radioButton3.Checked == false && radioButton4.Checked == false)
                {
                    MessageBox.Show("Introduceti culoarea!");
                }
                int an;
                double pret;
                if (textBox2.Text == "")
                {
                    MessageBox.Show("Introduceti modelul");
                    textBox2.BackColor = Color.Red;

                }
                else textBox2.BackColor = Color.GhostWhite;
                if (textBox4.Text == "" || double.TryParse(textBox4.Text, out pret) != true)
                {
                    MessageBox.Show("Introduceti Pretul/Format incorect!");
                    textBox4.BackColor = Color.Red;

                }
                else textBox4.BackColor = Color.GhostWhite;
                if (textBox3.Text == "" || int.TryParse(textBox3.Text, out an) != true)
                {
                    MessageBox.Show("Introduceti Stocul/Format incorect!");
                    textBox3.BackColor = Color.Red;

                }
                else textBox3.BackColor = Color.GhostWhite;
                if ((checkBox1.Checked == false && checkBox2.Checked == false) || (checkBox1.Checked == true && checkBox2.Checked == true))
                {
                    MessageBox.Show("Bifati doar o singura optiune(Mod Eliberare)!");
                }
                int anul = 0;
                double _pret = 0;
                if (int.TryParse(textBox3.Text, out anul) == true && double.TryParse(textBox4.Text, out _pret) == true && textBox1.Text != "" && textBox2.Text != "" && textBox3.Text != "" && textBox4.Text != "" && (radioButton2.Checked == true || radioButton3.Checked == true || radioButton4.Checked == true) && comboBox1.SelectedItem != null && (checkBox1.Checked == true && checkBox2.Checked == false) || (checkBox1.Checked == false && checkBox2.Checked == true))
                {
                    masine[k].tipul = comboBox1.SelectedItem.ToString();
                    masine[k].dot = GetDotari();
                    masine[k].pret = _pret;
                    masine[k].an = anul;
                    masine[k].model = textBox2.Text;
                    masine[k].color = GetCuloare();
                    masine[k].dataInchieri = DateTime.Now;

                    MessageBox.Show("Masina modificat!");
                }
            }
        }
        }
    }
